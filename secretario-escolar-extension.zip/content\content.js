// ── Detecta atividade na página ──────────────────────────────────────────────

function detectarAtividade() {
  const url = window.location.href
  const emAtividade = url.includes('/c/') && (url.includes('/a/') || url.includes('/sa/'))
  if (!emAtividade) return null

  const titulo = document.querySelector('h1, [data-item-id] h2')?.textContent?.trim() || ''

  const enunciado = [
    document.querySelector('.assignment-description'),
    document.querySelector('[data-description]'),
    document.querySelector('.instructions-text'),
    ...document.querySelectorAll('div[class*="description"]'),
  ].find(el => el?.textContent?.trim())?.textContent?.trim() || ''

  let tipoResposta = 'desconhecido'
  if (document.querySelector('textarea'))              tipoResposta = 'texto_curto'
  else if (document.querySelector('.docs-editor'))     tipoResposta = 'redacao'
  else if (document.querySelector('input[type="radio"]')) tipoResposta = 'multipla_escolha'

  return { titulo, enunciado, tipoResposta, url }
}

// ── Injeta resposta no campo correto ─────────────────────────────────────────

function injetarResposta(resposta, tipoResposta) {
  switch (tipoResposta) {
    case 'texto_curto': {
      const textarea = document.querySelector('textarea')
      if (textarea) {
        textarea.focus()
        // Native input setter para React/Angular detectar
        const nativeInputSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set
        nativeInputSetter.call(textarea, resposta)
        textarea.dispatchEvent(new Event('input', { bubbles: true }))
        textarea.dispatchEvent(new Event('change', { bubbles: true }))
      }
      break
    }
    case 'redacao': {
      const editor = document.querySelector('.docs-editor')
      if (editor) {
        editor.focus()
        document.execCommand('selectAll')
        document.execCommand('insertText', false, resposta)
      }
      break
    }
    case 'multipla_escolha': {
      const opcoes = document.querySelectorAll('input[type="radio"]')
      const letras = ['A', 'B', 'C', 'D']
      const index = letras.indexOf(resposta.toUpperCase())
      if (opcoes[index]) opcoes[index].click()
      break
    }
  }
  return true
}

// ── Clica no botão de entrega ─────────────────────────────────────────────────

function clicarEntregar() {
  const botoes = [...document.querySelectorAll('button')]
  const botao = botoes.find(b =>
    b.textContent.includes('Entregar') ||
    b.textContent.includes('Turn in') ||
    b.textContent.includes('Marcar como concluído')
  )
  if (!botao) return false
  botao.click()

  setTimeout(() => {
    const confirmar = [...document.querySelectorAll('button')].find(b =>
      b.textContent.includes('Entregar') || b.textContent.includes('Turn In')
    )
    if (confirmar) confirmar.click()
  }, 1000)
  return true
}

// ── Listener de mensagens do popup ───────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.tipo === 'DETECTAR')  sendResponse(detectarAtividade())
  if (msg.tipo === 'INJETAR')   sendResponse({ ok: injetarResposta(msg.resposta, msg.tipoResposta) })
  if (msg.tipo === 'ENTREGAR')  sendResponse({ ok: clicarEntregar() })
  return true
})
