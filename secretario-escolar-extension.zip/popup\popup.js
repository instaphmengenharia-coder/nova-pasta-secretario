const AGENTE_URL = 'https://agente-servidor-production.up.railway.app'

const telas = {
  fora:       document.getElementById('tela-fora'),
  atividade:  document.getElementById('tela-atividade'),
  rascunho:   document.getElementById('tela-rascunho'),
  entregando: document.getElementById('tela-entregando'),
  entregue:   document.getElementById('tela-entregue'),
}

function mostrar(tela) {
  Object.values(telas).forEach(t => t.classList.add('hidden'))
  telas[tela].classList.remove('hidden')
}

function setStatus(msg) {
  document.getElementById('status').textContent = msg
}

let atividadeAtual  = null
let respostaGerada  = null

// ── Init ──────────────────────────────────────────────────────────────────────

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

  if (!tab.url?.includes('classroom.google.com')) {
    mostrar('fora')
    return
  }

  let atividade = null
  try {
    atividade = await chrome.tabs.sendMessage(tab.id, { tipo: 'DETECTAR' })
  } catch {
    mostrar('fora')
    return
  }

  if (!atividade?.titulo) {
    mostrar('fora')
    return
  }

  atividadeAtual = atividade
  document.getElementById('titulo-atividade').textContent = atividade.titulo

  const tipoLabel = {
    texto_curto:    'Questão aberta',
    redacao:        'Redação / Docs',
    multipla_escolha: 'Múltipla escolha',
    desconhecido:   'Atividade',
  }
  document.getElementById('tipo-badge').textContent = tipoLabel[atividade.tipoResposta] || 'Atividade'

  mostrar('atividade')
}

// ── Resolver com IA ───────────────────────────────────────────────────────────

document.getElementById('btn-gerar').addEventListener('click', async () => {
  if (!atividadeAtual) return

  setStatus('Gerando resposta com IA…')
  document.getElementById('btn-gerar').disabled = true

  try {
    const { aluno, estiloExemplos } = await chrome.storage.local.get(['aluno', 'estiloExemplos'])

    const res = await fetch(`${AGENTE_URL}/atividade/gerar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        atividadeLida: atividadeAtual,
        aluno: aluno || { nome: 'Aluno', serie: 'Ensino Médio' },
        estiloExemplos: estiloExemplos || [],
      }),
    })

    if (!res.ok) throw new Error(`Servidor retornou ${res.status}`)
    const rascunho = await res.json()

    respostaGerada = rascunho.rascunho
    document.getElementById('rascunho-texto').value = respostaGerada

    const badge = document.getElementById('confianca')
    badge.textContent = `Confiança: ${rascunho.confianca}`
    badge.className = `badge-conf ${rascunho.confianca}`

    mostrar('rascunho')

  } catch (err) {
    setStatus('Erro: ' + err.message)
    document.getElementById('btn-gerar').disabled = false
  }
})

// ── Chat de refinamento ───────────────────────────────────────────────────────

document.getElementById('btn-chat').addEventListener('click', enviarChat)
document.getElementById('chat-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') enviarChat()
})

async function enviarChat() {
  const input = document.getElementById('chat-input')
  const msg   = input.value.trim()
  if (!msg) return

  const atual = document.getElementById('rascunho-texto').value
  input.value = ''

  // Mostra área de chat
  const chatArea = document.getElementById('chat-area')
  const chatMsgs = document.getElementById('chat-msgs')
  chatArea.classList.remove('hidden')

  // Mensagem do usuário
  const msgUser = document.createElement('div')
  msgUser.className = 'chat-msg-user'
  msgUser.textContent = msg
  chatMsgs.appendChild(msgUser)

  // Loading
  const loading = document.createElement('div')
  loading.className = 'chat-msg-ai'
  loading.textContent = '●  ●  ●'
  chatMsgs.appendChild(loading)
  chatMsgs.scrollTop = chatMsgs.scrollHeight

  document.getElementById('btn-chat').disabled = true

  try {
    const res = await fetch(`${AGENTE_URL}/atividade/refinar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ respostaAtual: atual, instrucao: msg }),
    })

    if (!res.ok) throw new Error(`Erro ${res.status}`)
    const data = await res.json()

    document.getElementById('rascunho-texto').value = data.resposta
    respostaGerada = data.resposta

    loading.textContent = '✓ Resposta atualizada!'
  } catch (err) {
    loading.textContent = 'Erro: ' + err.message
  } finally {
    document.getElementById('btn-chat').disabled = false
    chatMsgs.scrollTop = chatMsgs.scrollHeight
  }
}

// ── Aprovar e Entregar ────────────────────────────────────────────────────────

document.getElementById('btn-aprovar').addEventListener('click', async () => {
  const respostaFinal = document.getElementById('rascunho-texto').value

  // Save as style example (up to 3)
  if (atividadeAtual && respostaFinal) {
    const { estiloExemplos = [] } = await chrome.storage.local.get('estiloExemplos')
    const filtered = estiloExemplos.filter(e => e.task !== atividadeAtual.titulo)
    const updated = [{ task: atividadeAtual.titulo, answer: respostaFinal.slice(0, 600) }, ...filtered].slice(0, 3)
    await chrome.storage.local.set({ estiloExemplos: updated })
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

  mostrar('entregando')

  // 1. Injeta a resposta no campo
  await chrome.tabs.sendMessage(tab.id, {
    tipo: 'INJETAR',
    resposta: respostaFinal,
    tipoResposta: atividadeAtual.tipoResposta,
  })

  // 2. Aguarda 800ms e clica em Entregar
  await new Promise(r => setTimeout(r, 800))
  const resultado = await chrome.tabs.sendMessage(tab.id, { tipo: 'ENTREGAR' })

  if (resultado?.ok) {
    mostrar('entregue')
  } else {
    setStatus('⚠️ Resposta injetada, mas botão "Entregar" não foi encontrado. Clique manualmente.')
    mostrar('resposta')
  }
})

// ── Cancelar / Fechar ─────────────────────────────────────────────────────────

document.getElementById('btn-cancelar').addEventListener('click', () => {
  document.getElementById('btn-gerar').disabled = false
  setStatus('')
  mostrar('atividade')
})

document.getElementById('btn-voltar').addEventListener('click', () => window.close())

// ── Start ─────────────────────────────────────────────────────────────────────
init()
