// background.js — service worker da extensão
// 1. Executa comandos SE_COMMAND no tab do Classroom
// 2. Mantém WebSocket com Railway (para scheduler) com auto-reconexão

const RAILWAY_WS  = 'wss://agente-servidor-production.up.railway.app/extension'
const CLASSROOM   = 'https://classroom.google.com/*'

// ── WebSocket para o Railway (scheduler) ──────────────────────────────────────
let ws = null
let wsReconnectDelay = 2000
let wsUserId = null

async function getStoredUserId() {
  try {
    const data = await chrome.storage.local.get('userId')
    return data.userId || null
  } catch { return null }
}

function conectarWS() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return

  ws = new WebSocket(RAILWAY_WS)

  ws.onopen = async () => {
    wsReconnectDelay = 2000
    wsUserId = await getStoredUserId()
    if (wsUserId) ws.send(JSON.stringify({ type: 'auth', userId: wsUserId }))
    console.log('[WS] Conectado ao Railway')
  }

  ws.onmessage = async (event) => {
    try {
      const msg = JSON.parse(event.data)
      if (msg.type === 'ping') { ws.send(JSON.stringify({ type: 'pong' })); return }
      if (msg.type === 'command' && msg.id && msg.cmd) {
        const result = await executeCommand(msg.cmd).catch(err => ({ error: err.message }))
        ws.send(JSON.stringify({ type: 'result', id: msg.id, result }))
      }
    } catch { /* ignora frames inválidos */ }
  }

  ws.onclose = () => {
    console.log(`[WS] Desconectado — reconectando em ${wsReconnectDelay / 1000}s`)
    setTimeout(() => {
      wsReconnectDelay = Math.min(wsReconnectDelay * 2, 60000) // max 60s
      conectarWS()
    }, wsReconnectDelay)
  }

  ws.onerror = () => ws.close()
}

// Inicia WS ao instalar/acordar
chrome.runtime.onInstalled.addListener(() => {
  console.log('Secretário Escolar v2 instalado.')
  conectarWS()
})
chrome.runtime.onStartup.addListener(conectarWS)
conectarWS()

// Atualiza userId quando muda no storage
chrome.storage.onChanged.addListener((changes) => {
  if (changes.userId && ws?.readyState === WebSocket.OPEN) {
    wsUserId = changes.userId.newValue
    if (wsUserId) ws.send(JSON.stringify({ type: 'auth', userId: wsUserId }))
  }
})

// ── Execução de comandos no tab do Classroom ──────────────────────────────────
async function getClassroomTab() {
  const tabs = await chrome.tabs.query({ url: CLASSROOM })
  if (!tabs.length) throw new Error('Nenhuma aba do Classroom encontrada — abra classroom.google.com no Chrome')
  return tabs[0]
}

async function executeCommand(cmd) {
  switch (cmd.action) {
    case 'navigate': {
      const tab = await getClassroomTab()
      await chrome.tabs.update(tab.id, { url: cmd.url, active: true })
      // Aguarda carregamento completo (max 15s)
      await new Promise((resolve) => {
        const tid = setTimeout(resolve, 15000)
        function listener(tabId, info) {
          if (tabId === tab.id && info.status === 'complete') {
            clearTimeout(tid)
            chrome.tabs.onUpdated.removeListener(listener)
            resolve()
          }
        }
        chrome.tabs.onUpdated.addListener(listener)
      })
      return { ok: true, url: cmd.url }
    }

    case 'read_page': {
      const tab = await getClassroomTab()
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => (document.body?.innerText || document.body?.textContent || '').slice(0, 4000),
      })
      return { text: result }
    }

    case 'screenshot': {
      const tab = await getClassroomTab()
      await chrome.tabs.update(tab.id, { active: true })
      await new Promise(r => setTimeout(r, 300))
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 55 })
      return { screenshot: dataUrl }
    }

    case 'click': {
      const tab = await getClassroomTab()
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selector) => {
          const all = [...document.querySelectorAll('button,a,[role="button"],label,input[type="submit"]')]
          let el = all.find(e => (e.textContent || e.value || '').trim() === selector)
            || all.find(e => (e.textContent || e.value || '').trim().includes(selector))
          if (!el) { try { el = document.querySelector(selector) } catch {} }
          if (!el) return { error: `Elemento não encontrado: "${selector}"` }
          el.scrollIntoView({ block: 'center' })
          el.click()
          return { ok: true }
        },
        args: [cmd.selector],
      })
      return result
    }

    case 'fill': {
      const tab = await getClassroomTab()
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selector, value) => {
          let el
          try { el = document.querySelector(selector) } catch {}
          if (!el) return { error: `Campo não encontrado: "${selector}"` }
          el.focus()
          el.scrollIntoView({ block: 'center' })
          const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
          const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set
          if (setter) setter.call(el, value); else el.value = value
          el.dispatchEvent(new Event('input', { bubbles: true }))
          el.dispatchEvent(new Event('change', { bubbles: true }))
          return { ok: true }
        },
        args: [cmd.selector, cmd.value],
      })
      return result
    }

    case 'evaluate': {
      const tab = await getClassroomTab()
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (code) => {
          try { return { result: String(eval(code) ?? 'ok') } } catch (e) { return { error: e.message } } // eslint-disable-line no-eval
        },
        args: [cmd.code],
      })
      return result
    }

    case 'wait':
      await new Promise(r => setTimeout(r, cmd.ms || 1000))
      return { ok: true }

    default:
      return { error: `Ação desconhecida: ${cmd.action}` }
  }
}

// ── Listener para bridge.js ───────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'SE_COMMAND') return false
  executeCommand(msg.cmd)
    .then(result => sendResponse(result))
    .catch(err => sendResponse({ error: err.message }))
  return true // async
})
