// bridge.js — corre na página do Vercel, faz ponte postMessage ↔ chrome.runtime
;(function () {
  // Avisa a página que a extensão está ativa
  window.postMessage({ type: 'SE_EXT_STATUS', connected: true }, '*')

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.type !== 'SE_COMMAND') return
    const { reqId, cmd } = e.data

    chrome.runtime.sendMessage({ type: 'SE_COMMAND', cmd }, (result) => {
      const error = chrome.runtime.lastError?.message
      window.postMessage({
        type: 'SE_RESULT',
        reqId,
        result: error ? { error } : (result ?? { error: 'Sem resposta da extensão' }),
      }, '*')
    })
  })
})()
